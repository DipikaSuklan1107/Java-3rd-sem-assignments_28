class Student2 {
    String name;
    int id;

    public void initialize(String n, int i) {
        name = n;
        id = i;
    }
}

public class Main {
    public static void main(String[] args) {
        Student student1 = new Student();
        student1.initialize("Dipika Suklan", 12345);

        Student student2 = new Student();
        student2.initialize("Chandni Mehra", 67890);

        System.out.println("Student 1 - Name: " + student1.name + ", ID: " + student1.id);
        System.out.println("Student 2 - Name: " + student2.name + ", ID: " + student2.id);
    }
}
