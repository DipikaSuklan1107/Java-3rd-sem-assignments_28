class Student1 {
    String name;
    int id;

    public void initialize(String n, int i) {
        name = n;
        id = i;
    }
}

public class Main {
    public static void main(String[] args) {
        Student student = new Student() {
            {
                initialize("John Doe", 12345);
            }
        };

        System.out.println("Name: " + student.name + ", ID: " + student.id);
    }
}
