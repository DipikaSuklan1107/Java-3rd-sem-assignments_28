class SeperateMainClass {
    String name;
    int id;
}

public class Main {
    public static void main(String[] args) {
        Student student = new Student();
        student.name = "John Doe";
        student.id = 12345;

        System.out.println("Name: " + student.name + ", ID: " + student.id);
    }
}
