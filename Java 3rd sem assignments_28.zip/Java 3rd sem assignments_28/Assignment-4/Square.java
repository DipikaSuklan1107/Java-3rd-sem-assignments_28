class Square {
    double side;

    public void initialize(double s) {
        side = s;
    }

    public double calculateArea() {
        return side * side;
    }

    public double calculatePerimeter() {
        return 4 * side;
    }
}

public class Main {
    public static void main(String[] args) {
        Square square = new Square();
        square.initialize(5.0);

        double area = square.calculateArea();
        double perimeter = square.calculatePerimeter();

        System.out.println("Area: " + area);
        System.out.println("Perimeter: " + perimeter);
    }
}
