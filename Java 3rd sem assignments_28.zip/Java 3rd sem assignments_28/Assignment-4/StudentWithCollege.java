class StudentWithCollege {
    String name;
    int id;
    static String college = "MS Univerity";
}
