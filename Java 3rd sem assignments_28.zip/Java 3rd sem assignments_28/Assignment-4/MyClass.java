class MyClass {
    static int count = 0;

    public MyClass() {
        count++;
    }

    public static void printCount() {
        System.out.println("Number of objects created: " + count);
    }
}

public class Main {
    public static void main(String[] args) {
        MyClass obj1 = new MyClass();
        MyClass obj2 = new MyClass();
        MyClass obj3 = new MyClass();

        MyClass.printCount(); // This will print "Number of objects created: 3"
    }
}
