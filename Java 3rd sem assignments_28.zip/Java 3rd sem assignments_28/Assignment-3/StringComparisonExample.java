public class StringComparisonExample {
    public static void main(String[] args) {
        String s1 = "Krishna";
        String s2 = "Krishna";
        String s3 = new String("Krina");
        String s4 = "Krupali";

        System.out.println("Using equals() Method:");
        System.out.println("s1 equals s2: " + s1.equals(s2));
        System.out.println("s1 equals s3: " + s1.equals(s3));
        System.out.println("s1 equals s4: " + s1.equals(s4));
        System.out.println();

        System.out.println("Using == Operator:");
        System.out.println("s1 == s2: " + (s1 == s2));
        System.out.println("s1 == s3: " + (s1 == s3));
        System.out.println("s1 == s4: " + (s1 == s4));
        System.out.println();

        System.out.println("Using compareTo() Method:");
        System.out.println("s1 compared to s2: " + s1.compareTo(s2));
        System.out.println("s1 compared to s3: " + s1.compareTo(s3));
        System.out.println("s1 compared to s4: " + s1.compareTo(s4));
    }
}
