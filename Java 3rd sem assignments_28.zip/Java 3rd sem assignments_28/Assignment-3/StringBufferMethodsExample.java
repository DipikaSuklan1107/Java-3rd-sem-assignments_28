public class StringBufferMethodsExample {
    public static void main(String[] args) {
        StringBuffer stringBuffer = new StringBuffer("Hello");

        stringBuffer.append(" World");
        System.out.println("After append: " + stringBuffer);

        stringBuffer.insert(5, ", ");
        System.out.println("After insert: " + stringBuffer);

        stringBuffer.replace(0, 5, "Hi");
        System.out.println("After replace: " + stringBuffer);

        stringBuffer.delete(2, 4);
        System.out.println("After delete: " + stringBuffer);

        stringBuffer.reverse();
        System.out.println("After reverse: " + stringBuffer);

        int capacity = stringBuffer.capacity();
        System.out.println("Capacity: " + capacity);

        stringBuffer.ensureCapacity(20);
        System.out.println("After ensureCapacity: " + stringBuffer);

        char charAtIndex = stringBuffer.charAt(0);
        System.out.println("Character at index 0: " + charAtIndex);

        int length = stringBuffer.length();
        System.out.println("Length: " + length);

        String substring = stringBuffer.substring(3);
        System.out.println("Substring from index 3: " + substring);
    }
}
