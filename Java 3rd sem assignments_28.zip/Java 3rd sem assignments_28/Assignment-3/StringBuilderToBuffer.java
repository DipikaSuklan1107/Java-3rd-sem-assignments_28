public class StringBuilderToBuffer {
    public static void main(String[] args) {
        StringBuilder stringBuilder = new StringBuilder("Hello, World!");
        StringBuffer stringBuffer = new StringBuffer(stringBuilder);

        System.out.println("StringBuffer String: " + stringBuffer);
    }
}
