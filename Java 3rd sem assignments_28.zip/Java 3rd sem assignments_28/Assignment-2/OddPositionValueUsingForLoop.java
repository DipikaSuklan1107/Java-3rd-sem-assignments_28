public class OddPositionValueUsingForLoop {
    public static void main(String[] args) {
        int[] integers = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
        float[] floats = {1.1f, 2.2f, 3.3f, 4.4f, 5.5f};
        double[] doubles = {1.11, 2.22, 3.33, 4.44, 5.55, 6.66, 7.77, 8.88};
        short[] shorts = {10, 20, 30, 40};
        byte[] bytes = {1, 2, 3, 4, 5};
        
        int count = 1;
        for (int i : integers) {
            if (count % 2 != 0) {
                System.out.print(i + " ");
            }
            count++;
        }
        System.out.println();
        
        count = 1;
        for (float f : floats) {
            if (count % 2 != 0) {
                System.out.print(f + " ");
            }
            count++;
        }
        System.out.println();
        
        count = 1;
        for (double d : doubles) {
            if (count % 2 != 0) {
                System.out.print(d + " ");
            }
            count++;
        }
        System.out.println();
        
        count = 1;
        for (short s : shorts) {
            if (count % 2 != 0) {
                System.out.print(s + " ");
            }
            count++;
        }
        System.out.println();
        
        count = 1;
        for (byte b : bytes) {
            if (count % 2 != 0) {
                System.out.print(b + " ");
            }
            count++;
        }
        System.out.println();
    }
}
