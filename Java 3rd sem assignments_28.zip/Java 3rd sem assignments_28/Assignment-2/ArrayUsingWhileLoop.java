public class ArrayUsingWhileLoop {
    public static void main(String[] args) {
        int[] integers = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
        float[] floats = {1.1f, 2.2f, 3.3f, 4.4f, 5.5f};
        double[] doubles = {1.11, 2.22, 3.33, 4.44, 5.55, 6.66, 7.77, 8.88};
        short[] shorts = {10, 20, 30, 40};
        byte[] bytes = {1, 2, 3, 4, 5};
        
        int i = 0;
        while (i < 10) {
            System.out.print(integers[i] + " ");
            i++;
        }
        System.out.println();
        
        i = 0;
        while (i < 5) {
            System.out.print(floats[i] + " ");
            i++;
        }
        System.out.println();
        
        i = 0;
        while (i < 8) {
            System.out.print(doubles[i] + " ");
            i++;
        }
        System.out.println();
        
        i = 0;
        while (i < 4) {
            System.out.print(shorts[i] + " ");
            i++;
        }
        System.out.println();
        
        i = 0;
        while (i < 5) {
            System.out.print(bytes[i] + " ");
            i++;
        }
        System.out.println();
    }
}
