package com.mycompany.app;
import com.mycompany.math.*;
/**
 *
 * @author Varsha
 */
public class Main 
{

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
        // TODO code application logic herepublic static void main(String[] args)
    {
        Calculator calculator = new Calculator();
        
        
       int resultAdd = calculator.add(20,30);
       System.out.println("Addition Result:" + resultAdd);
       
       int resultSub= calculator.subtract(20,7);
       System.out.println("Subtraction Result:" + resultSub);
    }
    
}
