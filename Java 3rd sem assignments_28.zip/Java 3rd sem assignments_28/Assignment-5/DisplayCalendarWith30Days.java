import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Scanner;

public class DisplayCalendarWith30Days {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter year (e.g., 2023): ");
        int year = scanner.nextInt();

        System.out.print("Enter month (1 for January, 2 for February, ..., 12 for December): ");
        int month = scanner.nextInt();

        if (month < 1 || month > 12) {
            System.out.println("Invalid month. Please enter a valid month (1 to 12).");
            scanner.close();
            return;
        }

        Calendar calendar = new GregorianCalendar(year, month - 1, 1);

        calendar.set(Calendar.DAY_OF_MONTH, 1);

        System.out.println(" Sun  Mon  Tue  Wed  Thu  Fri  Sat");

        int firstDayOfWeek = calendar.get(Calendar.DAY_OF_WEEK);

        int daysInMonth = 30;

        for (int i = 1; i < firstDayOfWeek; i++) {
            System.out.print("     ");
        }

        for (int day = 1; day <= daysInMonth; day++) {
            System.out.printf("%4d", day);

            if ((day + firstDayOfWeek - 1) % 7 == 0 || day == daysInMonth) {
                System.out.println();
            }
        }

        scanner.close();
    }
}
