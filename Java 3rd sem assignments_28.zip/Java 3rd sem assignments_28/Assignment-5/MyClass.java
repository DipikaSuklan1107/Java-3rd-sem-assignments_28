class MyClass {
    private int myNumber; 

    public void setNumber(int myNumber) {
        this.myNumber = myNumber; 
    }

    public void displayNumber() {
        System.out.println("Value of myNumber: " + this.myNumber); 
    }
}

public class Main {
    public static void main(String[] args) {
        MyClass obj = new MyClass();

        obj.setNumber(42);
        obj.displayNumber();
    }
}
